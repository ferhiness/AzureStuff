﻿#Download powershell cmdlet https://github.com/Azure/azure-powershell/releases
#Changing to folder where .sqlpackage is 

cd "C:\Program Files (x86)\Microsoft SQL Server\130\DAC\bin\"


#Exporting database to a .bacpac file

.\SqlPackage.exe /Action:Export /SourceServerName:localhost /SourceDatabaseName:SourceDbName /TargetFile:"C:\SourceDbName_bacpac.bacpac" 

<#
AzCopy is a Windows command-line utility designed for copying data to and from Microsoft Azure Blob, File, 
and Table storage using simple commands with optimal performance. 
You can copy data from one object to another within your storage account, or between storage accounts.
Changing to folder where Azure copy command is 
#>
#Running AzCopy command
#Moving .bacpac file from our local drive to Azure storage container.

Cd "C:\Program Files (x86)\Microsoft SDKs\Azure\AzCopy"
.\AzCopy.exe /Source:"c:\" /Dest:https://StorageAccountName.blob.core.windows.net/swwstoragecontainer `
 /DestKey:keyofYourStorageAccount `
 /Pattern:SourceDbName_bacpac.bacpac

#Assuming you have a password saved in that file
$credentialPW=Get-Content "C:\HowToMigrate SQLDatabaseMicrosoftAzureSQL_V12\password.txt"

#Exporting .bacpac file directly to Azure SQL Server

cd "C:\Program Files (x86)\Microsoft SQL Server\130\DAC\bin\"
.\sqlpackage.exe /a:Import /sf:C:\SourceDbName_bacpac.bacpac /tsn:LogicalServerName.database.windows.net `
/tdn:SourceDbNameBACPAC1 `
/tu:taiobmdjamshed@LogicalServerName /tp:$credentialPW

#Restoring the .bacpac file from Azure storage container 
 
Login-AzureRmAccount

#Get-AzureRmResourceGroup


#Get-AzureRmSubscription –SubscriptionName "Visual Studio Professional" | Select-AzureRmSubscription 
#Set-azuresubscription

#Method 1 mostly hard coded value
New-AzureRmSqlDatabaseImport -ResourceGroupName "ResourceGrupName" -ServerName "LogicalServerName"  `
-DatabaseName "SourceDbNameBACPAC2"  -StorageKeyType "StorageAccessKey" `
-StorageKey "StorageAccountAccesskey" `
-StorageUri "https://StorageAccountName.blob.core.windows.net/swwstoragecontainer/SourceDbName_bacpac.bacpac"  `
-AdministratorLogin "SqlLogin" -Edition Standard -ServiceObjectiveName S0 -DatabaseMaxSizeBytes 50000


#Method 2 using variable and progress url
$ResourceGroupName = "ResourceGrupName"
$ServerName = 'LogicalServerName'
$DatabaseName = "SourceDbNameBACPAC3"

$StorageName = "StorageAccountName"
$StorageKeyType = "StorageAccessKey"
$StorageUri = "http://$StorageName.blob.core.windows.net/swwstoragecontainer/SourceDbName_bacpac.bacpac"
$StorageKey = "StorageAccountAccesskey" 

$credential = Get-Credential

$importRequest = New-AzureRmSqlDatabaseImport -ResourceGroupName $ResourceGroupName -ServerName $ServerName `
 -DatabaseName $DatabaseName -StorageKeytype $StorageKeyType -StorageKey $StorageKey `
 -StorageUri $StorageUri -AdministratorLogin $credential.UserName -AdministratorLoginPassword $credential.Password `
 -Edition Standard -ServiceObjectiveName S0 -DatabaseMaxSizeBytes 50000

Get-AzureRmSqlDatabaseImportExportStatus -OperationStatusLink $importRequest.OperationStatusLink



