--Cannot use "USE" statement with Azure

USE [Fabrics]
GO

--Here is a sample query to return a set of all user objects in a database:
--copied from
--https://blogs.msdn.microsoft.com/sqlcat/2016/10/20/migrating-from-sql-server-to-azure-sql-database-using-bacpac-files/
SELECT s.name AS [schema_name],
       o.name AS [object_name],
       o.type_desc AS [object_type_desc]
FROM sys.objects AS o
INNER JOIN sys.schemas AS s
ON o.schema_id = s.schema_id
WHERE s.name <> 'sys'
      AND
      o.is_ms_shipped = 0
      AND
      o.type NOT IN ('IT','S')
;


--count by object type
SELECT  db_name() AS [DatabaseName],
		s.name AS [schema_name],
       o.type_desc AS [object_type_desc],
	   COUNT(0) AS [countbyObjType]
FROM sys.objects AS o
INNER JOIN sys.schemas AS s
ON o.schema_id = s.schema_id
WHERE s.name <> 'sys'
      AND o.is_ms_shipped = 0
      AND o.type NOT IN ('IT','S')
	  AND db_name()<>'Master'
GROUP BY s.name, o.type_desc
;


--Here is a sample query to return the row count for each user table in a database:
--copied from
--https://blogs.msdn.microsoft.com/sqlcat/2016/10/20/migrating-from-sql-server-to-azure-sql-database-using-bacpac-files/
SELECT s.name AS [schema_name],
       t.name AS table_name,
       SUM(p.rows) AS row_count
FROM sys.partitions AS p
INNER JOIN sys.indexes AS i
ON p.object_id = i.object_id
   AND
   p.index_id = i.index_id
INNER JOIN sys.tables AS t
ON p.object_id = t.object_id
INNER JOIN sys.schemas AS s
ON t.schema_id = s.schema_id
WHERE s.name <> 'sys'
      AND
      t.is_ms_shipped = 0
      AND
      t.type NOT IN ('IT','S')
      AND
      i.type_desc IN ('HEAP','CLUSTERED','CLUSTERED COLUMNSTORE')
GROUP BY s.name, t.name
;