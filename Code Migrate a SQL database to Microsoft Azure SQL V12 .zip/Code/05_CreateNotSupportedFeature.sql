--This is a feature not allowed in Azure as of now. User name with \. 
--You can create this to simulate a failure in migration.
USE [Fabrics]
GO
CREATE USER [NT AUTHORITY\NETWORK SERVICE] FROM LOGIN [NT AUTHORITY\NETWORK SERVICE] WITH DEFAULT_SCHEMA =[dbo]
GO
--USE [Fabrics]
--GO
--DROP USER [NT AUTHORITY\NETWORK SERVICE]
--GO



