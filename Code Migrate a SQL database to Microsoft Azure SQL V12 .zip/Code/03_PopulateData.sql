USE [Fabrics]
GO
EXECUTE usp_Fabrics
GO