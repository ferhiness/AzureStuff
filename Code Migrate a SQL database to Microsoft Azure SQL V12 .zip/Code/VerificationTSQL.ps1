﻿#Log into your Azure Account
Login-AzureRmAccount

#Lookup Resource Group name
#Get-AzureRmResourceGroup

<#I want to open up the firewall rule only for the public IP address of the client on which I'm currently running. 
Since my IP might be NATed, I can't rely on the IP address of my current computer. 
Fortunately, there are a few websites that can return this information to me. 
One of them is http://myexternalip.com. We can either visit this URL via our browser, 
or we can just stay in PowerShell can get it via a script. Let's stick with PowerShell.
#>
#$publicIp = (Invoke-WebRequest http://myexternalip.com/raw).Content -replace "`n"

#Get SQL Server name
#Get-AzureRmSqlServer -ResourceGroupName swwazuretest

#Add-AzureAccount

#Setting up default subscription
#Get-AzureRmSubscription –SubscriptionName "put your subscription name" | Select-AzureRmSubscription 
#Set-azuresubscription

#Setting up firewal rule
#New-AzureSqlDatabaseServerFirewallRule  -ServerName swwazuretest -RuleName MyFirewallRule -StartIpAddress $publicIp -EndIpAddress $publicIp

#Assigning value to variable with server name
$ServerInstance = Get-AzureRmSqlServer -ResourceGroupName ResourceGroupName | where {$_.ServerName -eq 'LogicalServerName'}

#Deleting if file exist

$strFileName="c:\ObjCount.txt"
If (Test-Path $strFileName){
  Remove-Item $strFileName
}Else{
  # // File does not exist
}


$strFileName="c:\ObjCount.xml"
If (Test-Path $strFileName){
  Remove-Item $strFileName
}Else{
  # // File does not exist
}

$strFileName="c:\RowCount.txt"
If (Test-Path $strFileName){
  Remove-Item $strFileName
}Else{
  # // File does not exist
}


$strFileName="c:\RowCount.xml"
If (Test-Path $strFileName){
  Remove-Item $strFileName
}Else{
  # // File does not exist
}

#Getting all database name
$DatabaseName=Get-AzureRmSqlDatabase -ServerName LogicalServerName -ResourceGroupName ResourceGroupName | select databasename

#Loop through all database

#Do a count of objects
foreach ($Database in $DatabaseName){
$params = @{
    'Database' = $Database.databasename
    'ServerInstance' = 'LogicalServerName.database.windows.net'
    'Username' = 'sqlusername'
    'Password' = Get-Content 'C:\HowToMigrate SQLDatabaseMicrosoftAzureSQL_V12\password.txt'
    'Query' = 'SELECT  db_name() AS [DatabaseName],
		s.name AS [schema_name],
       o.type_desc AS [object_type_desc],
	   COUNT(0) AS [countbyObjType]
FROM sys.objects AS o
INNER JOIN sys.schemas AS s
ON o.schema_id = s.schema_id
WHERE s.name <> ''sys''
      AND o.is_ms_shipped = 0
      AND o.type NOT IN (''IT'',''S'')
      AND db_name()<>''Master''
GROUP BY s.name, o.type_desc
;'
        }
Invoke-Sqlcmd @params|Out-File -append C:\ObjCount.txt
}


#Show content is table format
Get-Content C:\ObjCount.txt|Format-Table -AutoSize

#Show content is grid view
Get-Content C:\ObjCount.txt|Out-GridView

#Export to xml
Get-Content C:\ObjCount.txt |Export-CliXML C:\ObjCount.xml 

#Improt xml and show in grid
Import-CliXML C:\ObjCount.xml | Out-GridView

#Do a row count of all objects
foreach ($Database in $DatabaseName){
$params = @{
    'Database' = $Database.databasename
    'ServerInstance' = 'LogicalServerName.database.windows.net'
    'Username' = 'sqlusername'
    'Password' = Get-Content 'C:\HowToMigrate SQLDatabaseMicrosoftAzureSQL_V12\password.txt'
    'Query' = 'SELECT db_name() AS [DatabaseName], s.name AS [schema_name],
       t.name AS table_name,
       SUM(p.rows) AS row_count
	   
FROM sys.partitions AS p
INNER JOIN sys.indexes AS i
ON p.object_id = i.object_id
   AND
   p.index_id = i.index_id
INNER JOIN sys.tables AS t
ON p.object_id = t.object_id
INNER JOIN sys.schemas AS s
ON t.schema_id = s.schema_id
WHERE s.name <> ''sys''
      AND
      t.is_ms_shipped = 0
      AND
      t.type NOT IN (''IT'',''S'')
      AND
      i.type_desc IN (''HEAP'',''CLUSTERED'',''CLUSTERED COLUMNSTORE'')
GROUP BY s.name, t.name'
        }
Invoke-Sqlcmd @params|Out-File -append C:\RowCount.txt
}


#Show content is table format
Get-Content C:\RowCount.txt|Format-Table -AutoSize

#Show content is grid view
Get-Content C:\RowCount.txt|Out-GridView

#Export to xml
Get-Content C:\RowCount.txt |Export-CliXML C:\RowCount.xml 

#Improt xml and show in grid
Import-CliXML C:\RowCount.xml | Out-GridView



